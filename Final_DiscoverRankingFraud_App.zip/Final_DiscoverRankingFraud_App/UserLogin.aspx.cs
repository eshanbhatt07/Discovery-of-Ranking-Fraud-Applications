﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["msg"] == "add")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Account Create Successfully')", true);
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from UserMaster where username=@u and password=@p");
            CommandType cmdType = CommandType.Text;
            SqlParameter[] para = { 
                                  new SqlParameter("@u",SqlDbType.VarChar){Value=txtUsername.Text},
                                  new SqlParameter("@p",SqlDbType.VarChar){Value=txtPassword.Text}
                                  };
            Helper objHelp = new Helper();
            DataTable dt = objHelp.GetData(cmd, para, cmdType);
            if (dt.Rows.Count > 0)
            {
                Session["name"] = dt.Rows[0]["name"].ToString();
                Session["id"] = dt.Rows[0]["uId"].ToString();
                Response.Redirect("User/Home.aspx");
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "message", "alert(Invalid Username and Password)", true);
            }
        }
    }
}