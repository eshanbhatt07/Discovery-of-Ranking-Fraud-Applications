﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App.Admin
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int pId = Convert.ToInt32(Request.QueryString["pId"]);
            if (!IsPostBack)
            {
                if (Request.QueryString["action"] == "edit")
                {
                    SqlCommand cmd = new SqlCommand("select pId, Username, Password, Name, Address, Phone, Email from ProviderMaster where pId=@pId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] sqlPara = { new SqlParameter("@pId", SqlDbType.Int) { Value = pId } };
                    Helper objHelp = new Helper();
                    DataTable dt = objHelp.GetData(cmd, sqlPara, cmdType);
                    if (dt.Rows.Count > 0)
                    {
                        txtUsername.Text = dt.Rows[0]["Username"].ToString();
                        txtPassword.Text = dt.Rows[0]["Password"].ToString();
                        txtName.Text = dt.Rows[0]["Name"].ToString();
                        txtAddress.Text = dt.Rows[0]["Address"].ToString();
                        txtEmail.Text = dt.Rows[0]["Email"].ToString();
                        txtPhone.Text = dt.Rows[0]["Phone"].ToString();
                    }
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int pId = Convert.ToInt32(Request.QueryString["pId"]);
            Helper objHelp = new Helper();
            if (Request.QueryString["action"] == "edit")
            {
                txtUsername.Enabled = false;
                txtPassword.Enabled = false;
                SqlCommand cmdUpdate = new SqlCommand("update ProviderMaster set Username=@Username, Password=@Password, Name=@Name, Address=@Address, Phone=@Phone, Email=@Email where pId=@pId");
                CommandType cmdType = CommandType.Text;
                SqlParameter[] sqlPara = { 
                                         new SqlParameter("@pId",SqlDbType.Int){Value=pId},
                                         new SqlParameter("@Username",SqlDbType.VarChar){Value=txtUsername.Text},
                                         new SqlParameter("@Password",SqlDbType.VarChar){Value=txtPassword.Text},
                                         new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                         new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                         new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                         new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text}
                                         };

                var res = objHelp.InsertData(cmdUpdate, sqlPara, cmdType);
                if (res.ToString() == "1")
                {
                    Response.Redirect("ManageProvider.aspx?msg=update");
                }
            }
            else
            {
                var check = objHelp.CheckUser(txtUsername.Text, "provider");
                if (check.ToString() == "1")
                {
                    SqlCommand cmdInsert = new SqlCommand("insert into ProviderMaster(Username, Password, Name, Address, Phone, Email)values(@Username, @Password, @Name, @Address, @Phone, @Email)");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] sqlPara = { 
                                         new SqlParameter("@Username",SqlDbType.VarChar){Value=txtUsername.Text},
                                         new SqlParameter("@Password",SqlDbType.VarChar){Value=txtPassword.Text},
                                         new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                         new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                         new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                         new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text}
                                         };
                    //Helper objHelp = new Helper();
                    var res = objHelp.InsertData(cmdInsert, sqlPara, cmdType);
                    if (res.ToString() == "1")
                    {
                        Response.Redirect("ManageProvider.aspx?msg=add");
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Messege", "alert('Username Not available')", true);
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageProvider.aspx");
        }
    }
}