﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App.Admin
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["msg"] == "add")
                {
                    ScriptManager.RegisterClientScriptBlock(this, GetType(), "Messege", "alert('User added Successfully')", true);
                }
                if (Request.QueryString["msg"] == "update")
                {
                    ScriptManager.RegisterClientScriptBlock(this, GetType(), "Messege", "alert('User Updated Successfully')", true);
                }
                fillGridView();
            }
        }
        protected void fillGridView()
        {
            SqlCommand cmd = new SqlCommand("select uId, Username, Password, Name, Address, Email, Phone, photo from UserMaster");
            CommandType cmdType = CommandType.Text;
            Helper objHelp = new Helper();
            DataTable dt = objHelp.GetData(cmd, null, cmdType);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            fillGridView();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                SqlCommand cmd = new SqlCommand("delete from UserMaster where uId=" + e.CommandArgument + "");
                CommandType cmdType = CommandType.Text;
                Helper objHelp = new Helper();
                var res = objHelp.InsertData(cmd, null, cmdType);
                if (res.ToString() == "1")
                {
                    fillGridView();
                }
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }
    }
}