﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App.Admin
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int uId = Convert.ToInt32(Request.QueryString["uId"]);
            if (!IsPostBack)
            {
                if (Request.QueryString["action"] == "edit")
                {
                    SqlCommand cmd = new SqlCommand("select uId, Username, Password, Name, Address, Email, Phone from dbo.UserMaster where uId=@uId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] para = { new SqlParameter("uId", SqlDbType.Int) { Value = uId } };
                    Helper objHelp = new Helper();
                    DataTable dt = objHelp.GetData(cmd, para, cmdType);
                    if (dt.Rows.Count <= 0) return;
                    txtUsername.Text = dt.Rows[0]["Username"].ToString();
                    txtPassword.Text = dt.Rows[0]["Password"].ToString();
                    txtName.Text = dt.Rows[0]["Name"].ToString();
                    txtAddress.Text = dt.Rows[0]["Address"].ToString();
                    txtEmail.Text = dt.Rows[0]["Email"].ToString();
                    txtPhone.Text = dt.Rows[0]["Phone"].ToString();
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int uId = Convert.ToInt32(Request.QueryString["uId"]);
            Helper objHelp = new Helper();
            if (Request.QueryString["action"] == "edit")
            {
                if (FileUpload1.HasFile)
                {
                    string filename = System.IO.Path.GetFileName(FileUpload1.FileName);
                    FileUpload1.SaveAs(Server.MapPath("~/ProfilePic/") + txtUsername.Text + filename);

                    string FilePath = "/ProfilePic/" + txtUsername.Text + filename;
                    SqlCommand cmdUpdate = new SqlCommand("update UserMaster set Photo=@Photo,Name=@Name,Address=@Address,Email=@Email,Phone=@Phone where uId=@uId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] sqlPara = {
                                            new SqlParameter("@uId",SqlDbType.Int){Value=uId},
                                            new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                            new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                            new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text},
                                            new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                             new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath}
                                         };

                    var res = objHelp.InsertData(cmdUpdate, sqlPara, cmdType);
                    if (res.ToString() == "1")
                    {
                        Response.Redirect("ManageUsers.aspx?msg=update");
                    }
                }
                else
                {
                    Response.Write("<script>alert('upload image.')</script>");
                    return;
                }
            }
            else
            {
                if (FileUpload1.HasFile)
                {
                    string filename = System.IO.Path.GetFileName(FileUpload1.FileName);
                    FileUpload1.SaveAs(Server.MapPath("~/ProfilePic/") + txtUsername.Text + filename);

                    string FilePath = "/ProfilePic/" + txtUsername.Text + filename;

                    var check = objHelp.CheckUser(txtUsername.Text, "user");
                    if (check.ToString() == "1")
                    {
                        SqlCommand cmdInsert = new SqlCommand("insert into UserMaster(Username, Password, Name, Address, Email, Phone,photo)values(@Username, @Password, @Name, @Address, @Email, @Phone,@photo)");
                        CommandType cmdType = CommandType.Text;
                        SqlParameter[] sqlPara = {
                                         new SqlParameter("@Username",SqlDbType.VarChar){Value=txtUsername.Text.Trim()},
                                         new SqlParameter("@Password",SqlDbType.VarChar){Value=txtPassword.Text.Trim()},
                                         new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text.Trim()},
                                         new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                         new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text},
                                         new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                         new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath}                                           
                                         };
                        //Helper objHelp = new Helper();
                        var res = objHelp.InsertData(cmdInsert, sqlPara, cmdType);
                        if (res.ToString() == "1")
                        {
                            Response.Redirect("ManageUsers.aspx?msg=add");
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Messege", "alert('Username Not available')", true);
                    }
                }
                else
                {
                    Response.Write("<script>alert('upload image.')</script>");
                    return;
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageUsers.aspx");
        }
    }
}