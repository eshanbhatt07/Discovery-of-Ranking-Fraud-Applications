﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using java.io;
using edu.stanford.nlp.tagger.maxent;
using edu.stanford.nlp.ling;
using javac = com.sun.tools.javac.util;
using java.util;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

namespace DiscoverRankingFraud_App.Admin
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        String posstring;
        string newString;
        public SqlConnection _conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);
        public string Model = HttpContext.Current.Server.MapPath(@"~\Bin\english-caseless-left3words-distsim.tagger");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillGridView();
            }
        }
        private void TagReader(Reader reader)
        {
            var tagger = new MaxentTagger(Model);
            //List obj = (List)MaxentTagger.tokenizeText(reader);
            foreach (ArrayList sentence in MaxentTagger.tokenizeText(reader).toArray())
            {
                var tSentence = tagger.tagSentence(sentence);
                System.Console.WriteLine(Sentence.listToString(tSentence, false));
                posstring = (Sentence.listToString(tSentence, false));
                newString = newString + posstring;
                System.Console.WriteLine();
            }
        }

        private void fillGridView()
        {
            SqlCommand cmd = new SqlCommand("select case substring(maliciousurl, 1, 14) when 'http://bit.ly/' then 'fraud ' end as Frauddata ,a.aId, a.Name, a.Description, a.Photo, a.Path, a.isActivate,COUNT(d.aId)as DownloadCount,isnull(AVG(r.Rating),0)as Ratings from AppMaster a join dbo.DownloadMaster d on(a.aId=d.aId)left join dbo.RatingMaster r on(a.aId=r.aId) group by a.aId, a.Name, a.Description, a.Photo, a.Path,a.maliciousurl, a.isActivate order by DownloadCount desc");
            CommandType cmdType = CommandType.Text;
            Helper objHelp = new Helper();
            DataTable dt = objHelp.GetData(cmd, null, cmdType);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            fillGridView();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
           
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    int AppID = Convert.ToInt32(e.Row.Cells[0].Text);
                    SqlCommand cmdGet = new SqlCommand("select case when AVG(rating) is null then 0 else AVG(rating) end as AvgRating from RatingMaster where aId=@aId;select reviewId, uId, aId, Review from dbo.ReviewMaster where aId=@aId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] paraMain = { 
                                            new SqlParameter("@aId",SqlDbType.Int){Value=AppID}
                                            };
                    Helper objHelp = new Helper();
                    DataSet dsMain = objHelp.GetDataSet(cmdGet, paraMain, cmdType);
                    if (Convert.ToInt32(dsMain.Tables[0].Rows[0]["AvgRating"]) <= 5)
                    {
                        truncate();
                        foreach (DataRow row in dsMain.Tables[1].Rows)
                        {
                            newString = "";
                            TagReader(new StringReader(row["Review"].ToString()));
                            string[] para = newString.Split('.');
                            List<string> lstNN = new List<string>();
                            List<string> lstJJ = new List<string>();
                            for (int i = 0; i < para.Length; i++)
                            {
                                string line = para[i];
                                string[] word = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                                for (int j = 0; j < word.Length; j++)
                                {
                                    int startindex = word[j].IndexOf("/");
                                    if (startindex < 0) { startindex = 0; }
                                    int lastindex = word[j].Length;
                                    string NewPos = word[j].Remove(0, startindex);
                                    string NewWord = word[j].Substring(0, startindex);
                                    switch (NewPos)
                                    {
                                        case "/NN":
                                            {
                                                lstNN.Add(NewWord);
                                                break;
                                            }
                                        case "/JJ":
                                            {
                                                lstJJ.Add(NewWord);
                                                break;
                                            }
                                        default:
                                            { break; }
                                    }
                                }
                                for (int jj = 0; lstJJ.Count < lstNN.Count; jj++)
                                {
                                    if (lstNN.Count > lstJJ.Count && lstNN.Count > 0)
                                    {
                                        lstNN.RemoveAt(lstNN.Count - 1);
                                    }
                                }
                                for (int nn = 0; lstNN.Count < lstJJ.Count; nn++)
                                {
                                    if (lstJJ.Count > lstNN.Count && lstJJ.Count > 0)
                                    {
                                        lstJJ.RemoveAt(lstJJ.Count - 1);
                                    }
                                }

                                for (int k = 0; k < lstNN.Count; k++)
                                {
                                    SqlDataAdapter da = new SqlDataAdapter("insert into FO_Table(Feature) values('" + lstNN[k] + "')", objHelp._conn);
                                    objHelp._conn.Open();
                                    da.SelectCommand.ExecuteNonQuery();
                                    objHelp._conn.Close();

                                    string query = "select * from SentiWordNet where SynsetTerms='" + lstJJ[k] + "'";
                                    // string query = "select max(PosScore)as PosScore,max(NegScore)as NegScore from SentiWordNet where SynsetTerms='" + lstJJ[k] + "'";
                                    SqlDataAdapter da1 = new SqlDataAdapter(query, objHelp._conn);
                                    objHelp._conn.Open();
                                    da1.SelectCommand.ExecuteNonQuery();
                                    DataTable dt = new DataTable();
                                    da1.Fill(dt);
                                    objHelp._conn.Close();
                                    if (dt.Rows.Count > 0)
                                    {
                                        double posvalue = Convert.ToDouble(dt.Rows[0]["PosScore"]);
                                        double Negvalue = Convert.ToDouble(dt.Rows[0]["NegScore"]);
                                        if (posvalue > Negvalue)
                                        {
                                            string feature = lstNN[k];
                                            string NewWord = lstJJ[k];
                                            objHelp._conn.Open();
                                            SqlDataAdapter da3 = new SqlDataAdapter(new SqlCommand("update FO_Table set PositivePolarity=" + 1 + ",value='" + NewWord + "' where Feature='" + feature + "'", objHelp._conn));
                                            da3.SelectCommand.ExecuteNonQuery();
                                            objHelp._conn.Close();
                                        }
                                        else if (Negvalue > posvalue || Negvalue != 0)
                                        {
                                            string feature = lstNN[k];
                                            string NewWord = lstJJ[k];
                                            objHelp._conn.Open();
                                            SqlDataAdapter da3 = new SqlDataAdapter("update FO_Table set NegativePolarity=" + 1 + ",value='" + NewWord + "' where feature='" + feature + "'", objHelp._conn);
                                            da3.SelectCommand.ExecuteNonQuery();
                                            objHelp._conn.Close();
                                        }
                                    }
                                }
                                lstNN.Clear();
                                lstJJ.Clear();
                            }
                        }//End Foreach dsMain

                        SqlDataAdapter daResult = new SqlDataAdapter("select count(PositivePolarity)as Pos,count(NegativePolarity)as Neg from FO_Table", objHelp._conn);
                        DataTable dtResult = new DataTable();
                        daResult.Fill(dtResult);
                        int PosCount = Convert.ToInt32(dtResult.Rows[0]["Pos"]);
                        int NegCount = Convert.ToInt32(dtResult.Rows[0]["Neg"]);

                        if (PosCount > NegCount)
                        {
                            if (Convert.ToInt32(dsMain.Tables[0].Rows[0]["AvgRating"]) <= 2)
                            {
                                e.Row.Cells[5].Text = "App is fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Red;
                            }
                            else
                            {
                                e.Row.Cells[5].Text = "App is not fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Green;
                            }
                        }
                        else if (NegCount > PosCount)
                        {
                            if (Convert.ToInt32(dsMain.Tables[0].Rows[0]["AvgRating"]) >= 3)
                            {
                                e.Row.Cells[5].Text = "App is fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Red;
                            }
                            else
                            {
                                e.Row.Cells[5].Text = "App is not fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Green;
                            }

                        }
                        else
                        {
                            if (Convert.ToInt32(dsMain.Tables[0].Rows[0]["AvgRating"]) >= 3)
                            {
                                e.Row.Cells[5].Text = "App is not fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Green;
                            }
                            else
                            {
                                e.Row.Cells[5].Text = "App is fraud";
                                e.Row.Cells[5].ForeColor = System.Drawing.Color.Red;
                            }
                        }
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        protected void truncate()
        {
            Helper objHelp = new Helper();
            SqlCommand cmd = new SqlCommand("truncate table FO_Table", objHelp._conn);
            objHelp._conn.Open();
            cmd.ExecuteNonQuery();
            objHelp._conn.Close();
        }
    }
}