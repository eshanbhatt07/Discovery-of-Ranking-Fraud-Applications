﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App.Admin
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillGridView();
            }
        }

        private void fillGridView()
        {
            SqlCommand cmd = new SqlCommand("select pId, Username, Password, Name, Address, Phone, Email from ProviderMaster");
            CommandType cmdType = CommandType.Text;
            Helper objHelp = new Helper();
            DataTable dt = objHelp.GetData(cmd, null, cmdType);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            fillGridView();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                SqlCommand cmd = new SqlCommand("delete from ProviderMaster where pId=" + e.CommandArgument + "");
                CommandType cmdType = CommandType.Text;
                Helper objHelp = new Helper();
                var res = objHelp.InsertData(cmd, null, cmdType);
                if (res.ToString() == "1")
                {
                    fillGridView();
                }
            }
        }
    }
}