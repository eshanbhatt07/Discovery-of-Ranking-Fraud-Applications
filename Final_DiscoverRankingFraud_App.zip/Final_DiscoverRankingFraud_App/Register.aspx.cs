﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["type"] == "1")
                {
                    ddlType.SelectedIndex = 1;
                }
                else if (Request.QueryString["type"] == "2")
                {
                    ddlType.SelectedIndex = 2;
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Helper objHelp = new Helper();
            if (ddlType.SelectedValue == "1")
            {
                SqlCommand cmd = new SqlCommand("insert into ProviderMaster(Username, Password, Name, Address, Phone, Email)values(@Username, @Password, @Name, @Address, @Phone, @Email)");
                CommandType cmdType = CommandType.Text;
                SqlParameter[] para ={
                                         new SqlParameter("@Username",SqlDbType.VarChar){Value=txtUsername.Text},
                                         new SqlParameter("@Password",SqlDbType.VarChar){Value=txtPassword.Text},
                                         new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                         new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                         new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                         new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text}
                                    };
                var res = objHelp.InsertData(cmd, para, cmdType);
                if (res.ToString() == "1")
                {
                    Response.Redirect("ProviderLogin.aspx?msg=add");
                }
            }
            else
            {
                SqlCommand cmd = new SqlCommand("insert into UserMaster(Username, Password, Name, Address, Phone, Email)values(@Username, @Password, @Name, @Address, @Phone, @Email)");
                CommandType cmdType = CommandType.Text;
                SqlParameter[] para ={
                                         new SqlParameter("@Username",SqlDbType.VarChar){Value=txtUsername.Text},
                                         new SqlParameter("@Password",SqlDbType.VarChar){Value=txtPassword.Text},
                                         new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                         new SqlParameter("@Address",SqlDbType.VarChar){Value=txtAddress.Text},
                                         new SqlParameter("@Phone",SqlDbType.VarChar){Value=txtPhone.Text},
                                         new SqlParameter("@Email",SqlDbType.VarChar){Value=txtEmail.Text}
                                    };
                var res = objHelp.InsertData(cmd, para, cmdType);
                if (res.ToString() == "1")
                {
                    Response.Redirect("UserLogin.aspx?msg=add");
                }
            }
        }
    }
}