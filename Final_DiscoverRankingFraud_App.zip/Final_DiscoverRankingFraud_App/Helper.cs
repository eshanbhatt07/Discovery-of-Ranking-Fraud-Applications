﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App
{

    public class Helper
    {
        SqlCommand objCmd = new SqlCommand();
        SqlDataAdapter objDa = new SqlDataAdapter();
        DataTable objDt;
        DataSet objDs;
        public SqlConnection _conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);
        public DataTable GetData(SqlCommand sqlQuery, SqlParameter[] sqlPara, CommandType sqlType)
        {
            try
            {
                objCmd = sqlQuery;
                objCmd.CommandType = sqlType;
                objCmd.Connection = _conn;
                if (sqlPara != null)
                {
                    objCmd.Parameters.AddRange(sqlPara);
                }
                using (objDa = new SqlDataAdapter(objCmd))
                {
                    objDt = new DataTable();
                    objDa.Fill(objDt);
                    if (objDt.Rows.Count > 0)
                        return objDt;
                    else
                        return objDt;
                }
            }
            finally
            {
                _conn.Close();
            }
        }

        public DataSet GetDataSet(SqlCommand sqlQuery, SqlParameter[] sqlPara, CommandType sqlType)
        {
            try
            {
                objCmd = sqlQuery;
                objCmd.CommandType = sqlType;
                objCmd.Connection = _conn;
                if (sqlPara != null)
                {
                    objCmd.Parameters.AddRange(sqlPara);
                }
                using (objDa = new SqlDataAdapter(objCmd))
                {
                    objDs = new DataSet();
                    objDa.Fill(objDs);
                    if (objDs.Tables[0].Rows.Count > 0)
                        return objDs;
                    else
                        return objDs;
                }
            }
            finally
            {
                _conn.Close();
            }
        }

        public string InsertData(SqlCommand sqlQuery, SqlParameter[] sqlPara, CommandType sqlType)
        {
            try
            {
                objCmd = sqlQuery;
                objCmd.CommandType = sqlType;
                objCmd.Connection = _conn;
                if (sqlPara != null)
                {
                    objCmd.Parameters.AddRange(sqlPara);
                }
                _conn.Open();
                var res = objCmd.ExecuteNonQuery();
                _conn.Close();
                if (res.ToString() == "1")
                {
                    return "1";
                }
                else
                {
                    return "0";
                }
            }
            finally
            {
                _conn.Close();
            }
        }
        public string CheckUser(string Username, string UserType)
        {
            if (UserType == "user")
            {
                objCmd = new SqlCommand("select Username from UserMaster where username=@u", _conn);
                objCmd.Parameters.Add("@u", Username);
                using (objDa = new SqlDataAdapter(objCmd))
                {
                    objDt = new DataTable();
                    objDa.Fill(objDt);
                    if (objDt.Rows.Count > 0)
                        return "0";
                    else
                        return "1";
                }
            }
            else if (UserType == "provider")
            {
                objCmd = new SqlCommand("select Username from ProviderMaster where username=@u", _conn);
                objCmd.Parameters.Add("@u", Username);
                using (objDa = new SqlDataAdapter(objCmd))
                {
                    objDt = new DataTable();
                    objDa.Fill(objDt);
                    if (objDt.Rows.Count > 0)
                        return "0";
                    else
                        return "1";
                }
            }
            return "0";
        }
    }
}