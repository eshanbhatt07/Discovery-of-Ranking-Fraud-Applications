﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace DiscoverRankingFraud_App.User
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlDataAdapter daGetPostUser = new SqlDataAdapter("GetPostData", conn);
                daGetPostUser.SelectCommand.CommandType = CommandType.StoredProcedure;
                daGetPostUser.SelectCommand.Parameters.AddWithValue("@User_id", Session["ID"].ToString());
                DataTable dt = new DataTable();
                daGetPostUser.Fill(dt);
                rp.DataSource = dt;
                rp.DataBind();
            }
        }


        protected void rp_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                int PostId = Convert.ToInt32(((System.Data.DataRowView)(e.Item.DataItem)).Row.ItemArray[0]);

                SqlDataAdapter daGetComments = new SqlDataAdapter("select cm.PostId, cm.User_id, cm.Comment,u.Name from CommentMaster cm inner join UserMaster u on (cm.User_Id=u.uId)  where cm.PostId=@PostId", conn);
                daGetComments.SelectCommand.Parameters.AddWithValue("@PostId", PostId);
                DataTable dtGetComment = new DataTable();
                daGetComments.Fill(dtGetComment);
                Repeater rp2 = (Repeater)e.Item.FindControl("rpComments");
                rp2.DataSource = dtGetComment;
                rp2.DataBind();
            }
        }

        protected void rp_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Comment")
            {
                int postId = Convert.ToInt32(e.CommandArgument);
                TextBox textBox = ((TextBox)e.Item.FindControl("txtComment"));
                String Comment = textBox.Text;
                SqlCommand cmdInsertComment = new SqlCommand("insert into CommentMaster(PostId, User_id, Comment)values(@PostId, @User_id, @Comment)", conn);
                cmdInsertComment.Parameters.AddWithValue("@PostId", postId);
                cmdInsertComment.Parameters.AddWithValue("@User_id", Session["ID"].ToString());
                cmdInsertComment.Parameters.AddWithValue("@Comment", Comment);
                conn.Open();
                cmdInsertComment.ExecuteNonQuery();
                conn.Close();
                Response.Redirect("Home.aspx");
            }
        }
    }
}