﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace DiscoverRankingFraud_App.User
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection _con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlCommand cmdSearch = new SqlCommand("select * from UserMaster where (Name like '%" + txtSearch.Text + "%' or Email like '%" + txtSearch.Text + "%') and uId<>" + Session["ID"].ToString() + "", _con);
            cmdSearch.CommandType = CommandType.Text;
            SqlDataAdapter daSearch = new SqlDataAdapter(cmdSearch);
            DataTable dtSearch = new DataTable();
            daSearch.Fill(dtSearch);

            GridView1.DataSource = dtSearch;
            GridView1.DataBind();
        }

        //protected void Button1_OnRowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    int Friend_id = Convert.ToInt32(e.CommandArgument);

        //    SqlCommand cmdinsert = new SqlCommand("insert into FriendMaster(FromUser, ToUser, Flag) values(@FromUser, @ToUser, @Flag)", _con);
        //    cmdinsert.CommandType = CommandType.Text;
        //    cmdinsert.Parameters.AddWithValue("@FromUser", Session["ID"].ToString());
        //    cmdinsert.Parameters.AddWithValue("@ToUser", Friend_id);
        //    cmdinsert.Parameters.AddWithValue("@Flag", 0);
        //    _con.Open();

        //    cmdinsert.ExecuteNonQuery();
        //    _con.Close();

        //    lblShow.Text = "Send Request";
        //}

        protected void GridView1_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "SendRequest") return;
            int Friend_id = Convert.ToInt32(e.CommandArgument);

            SqlCommand cmdinsert = new SqlCommand("insert into FriendMaster(FromUser, ToUser, Flag) values(@FromUser, @ToUser, @Flag)", _con);
            cmdinsert.CommandType = CommandType.Text;
            cmdinsert.Parameters.AddWithValue("@FromUser", Session["ID"].ToString());
            cmdinsert.Parameters.AddWithValue("@ToUser", Friend_id);
            cmdinsert.Parameters.AddWithValue("@Flag", 0);
            _con.Open();

            cmdinsert.ExecuteNonQuery();
            _con.Close();

            lblShow.Text = "Send Request";
        }
    }
}