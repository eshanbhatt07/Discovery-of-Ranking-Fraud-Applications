﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using System.Data;
using System.Data.SqlClient;

namespace DiscoverRankingFraud_App.User
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        public static DataTable dtReview;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int aId = Convert.ToInt32(Request.QueryString["aId"]);
                txtUsername.Text = Session["name"].ToString();

                SqlCommand cmd = new SqlCommand("select aId, Name, Description, Photo, Path, isActivate from AppMaster where aId=@aId;SELECT ISNULL(AVG(Rating), 0) AverageRating, COUNT(Rating) RatingCount FROM RatingMaster where aid=@aId;select rating from RatingMaster where uId=@uId and aId=@aId;select r.reviewId, r.uId,u.Name, r.aId, r.Review from ReviewMaster r join UserMaster u on(r.uId=u.uId) where r.aId=@aId");
                CommandType cmdType = CommandType.Text;
                SqlParameter[] para = { 
                                        new SqlParameter("@aId",SqlDbType.Int){Value=aId},
                                        new SqlParameter("@uId",SqlDbType.Int){Value=Convert.ToInt32(Session["id"])}
                                      };
                Helper onjHelp = new Helper();
                DataSet ds = onjHelp.GetDataSet(cmd, para, cmdType);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtName.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    Image1.ImageUrl = ds.Tables[0].Rows[0]["Photo"].ToString();
                    Rating1.CurrentRating = Convert.ToInt32(ds.Tables[1].Rows[0]["AverageRating"]);
                    if (ds.Tables[2].Rows.Count > 0)
                        Rating2.CurrentRating = Convert.ToInt32(ds.Tables[2].Rows[0]["rating"]);
                    else
                        Rating2.CurrentRating = 0;
                    dtReview = ds.Tables[3];
                }
            }
        }
        protected void OnRatingChanged(object sender, RatingEventArgs e)
        {
            int aId = Convert.ToInt32(Request.QueryString["aId"]);
            Helper objHelp = new Helper();
            SqlCommand cmdGetDetails = new SqlCommand("select rId,rating from RatingMaster where uId=@uId and aId=@aId");
            CommandType cmdType = CommandType.Text;
            SqlParameter[] paraDetails = { 
                                         new SqlParameter("@uId",SqlDbType.Int){Value=Convert.ToInt32(Session["id"])},
                                         new SqlParameter("@aId",SqlDbType.Int){Value=aId}
                                         };
            DataTable dtDetails = objHelp.GetData(cmdGetDetails, paraDetails, cmdType);
            if (dtDetails.Rows.Count > 0)
            {
                SqlCommand cmdUpdate = new SqlCommand("update RatingMaster set Rating=@rating where rId=@rId");
                SqlParameter[] paraUpdate = { 
                                            new SqlParameter("@rating",SqlDbType.Int){Value=e.Value},
                                            new SqlParameter("@rId",SqlDbType.Int){Value=Convert.ToInt32(dtDetails.Rows[0]["rId"])}
                                            };
                var res = objHelp.InsertData(cmdUpdate, paraUpdate, cmdType);
                if (res.ToString() == "1")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Rating update successfully')", true);
                }
            }
            else
            {
                SqlCommand cmdInsert = new SqlCommand("insert into RatingMaster(uId, aId, Rating)values(@uId, @aId, @Rating)");
                SqlParameter[] paraInsert = {
                                                new SqlParameter("@uId",SqlDbType.Int){Value=Convert.ToInt32(Session["id"])},
                                                new SqlParameter("@aId",SqlDbType.Int){Value=aId},
                                                new SqlParameter("@Rating",SqlDbType.Int){Value=e.Value}
                                            };
                var res = objHelp.InsertData(cmdInsert, paraInsert, cmdType);
                if (res.ToString() == "1")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Rating Insert successfully')", true);
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int aId = Convert.ToInt32(Request.QueryString["aId"]);
            SqlCommand cmdInsert = new SqlCommand("insert into ReviewMaster(uId, aId, Review)values(@uId, @aId, @Review)");
            CommandType cmdType = CommandType.Text;
            SqlParameter[] para = { 
                                  new SqlParameter("@uId",SqlDbType.Int){Value=Convert.ToInt32(Session["id"])},
                                  new SqlParameter("@aId",SqlDbType.Int){Value=aId},
                                  new SqlParameter("@Review",SqlDbType.VarChar){Value=txtReview.Text}
                                  };
            Helper objHelp = new Helper();
            var res = objHelp.InsertData(cmdInsert, para, cmdType);
            if (res.ToString() == "1")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Message", "alert('Review submit Successfully')", true);
            }
            Response.Redirect(Request.Url.AbsoluteUri);
        }
    }
}