﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace DiscoverRankingFraud_App.User
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlConnection _con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["msg"] == "Add")
            {
                lblShow.Text = "Friend Request Accepted";
            }
            if (Request.QueryString["msg"] == "reject")
            {
                lblShow.Text = "Friend Request Rejected";
            }
            if (!IsPostBack)
            {
                SqlCommand cmdSelect = new SqlCommand("select f.ID,u.Name,u.Email,f.FromUser from FriendMaster f join UserMaster u on(f.FromUser=u.uId) and f.ToUser=@ToUser and Flag=0", _con);
                cmdSelect.CommandType = CommandType.Text;
                cmdSelect.Parameters.AddWithValue("@ToUser", Session["ID"].ToString());
                SqlDataAdapter daSelect = new SqlDataAdapter(cmdSelect);
                DataTable dtSelect = new DataTable();
                daSelect.Fill(dtSelect);
                if (dtSelect.Rows.Count > 0)
                {
                    GridView1.DataSource = dtSelect;
                    GridView1.DataBind();
                }
            }
        }


        protected void btnAccept_OnCommand(object sender, CommandEventArgs e)
        {
            int RequetId = Convert.ToInt32(e.CommandArgument);
            SqlCommand cmdUpdate = new SqlCommand("update FriendMaster set Flag=1 where Id=" + RequetId + "", _con);
            cmdUpdate.CommandType = CommandType.Text;
            _con.Open();
            cmdUpdate.ExecuteNonQuery();
            _con.Close();

            Response.Redirect("Request.aspx?msg=Add");

        }

        protected void btnReject_OnCommand(object sender, CommandEventArgs e)
        {
            int RequetId = Convert.ToInt32(e.CommandArgument);
            SqlCommand cmdUpdate = new SqlCommand("delete from FriendMaster where Id=" + RequetId + "", _con);
            cmdUpdate.CommandType = CommandType.Text;
            _con.Open();
            cmdUpdate.ExecuteNonQuery();
            _con.Close();

            Response.Redirect("Request.aspx?msg=reject");
        }
    }
}