﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace DiscoverRankingFraud_App.User
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        SqlConnection _con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillddlFriend();
                FillRepeater();
            }
        }
        protected void FillddlFriend()
        {
            //SqlCommand cmdSelect = new SqlCommand("FriendList", _con);
            //cmdSelect.CommandType = CommandType.StoredProcedure;
            //cmdSelect.Parameters.AddWithValue("@id", Session["ID"].ToString());
            //SqlDataAdapter daSelect = new SqlDataAdapter(cmdSelect);
            //DataTable dtSelect = new DataTable();
            //daSelect.Fill(dtSelect);
            //if (dtSelect.Rows.Count > 0)
            //{
            //    ddlFriend.DataSource = dtSelect;
            //    ddlFriend.DataBind();
            //    ddlFriend.Items.Insert(0, new ListItem("Select Friend", "0"));
            //}

            SqlCommand cmdSelect = new SqlCommand("select ID,ToUser,(select Name from UserMaster where uId=ToUser)as ReciverName,'true' as RequestSend, 'false' as RequestRecived  from FriendMaster where FromUser = @id and Flag = 1", _con);
            cmdSelect.Parameters.AddWithValue("@id", Session["ID"].ToString());
            SqlDataAdapter daSelect = new SqlDataAdapter(cmdSelect);
            DataTable dtSelect = new DataTable();
            daSelect.Fill(dtSelect);
            if (dtSelect.Rows.Count > 0)
            {
                ddlFriend.DataSource = dtSelect;
                ddlFriend.DataTextField = "ReciverName";
                ddlFriend.DataValueField = "ToUser";
                ddlFriend.DataBind();

            }
            ddlFriend.Items.Insert(0, new ListItem("Select Friend", "0"));
        }

        protected void FillRepeater()
        {
            SqlDataAdapter daGetPosts = new SqlDataAdapter("Select PostId, FromUser, ToUser, PostContent, Date from PostData where FromUser =@FromUser", _con);
            daGetPosts.SelectCommand.Parameters.AddWithValue("@FromUser", Session["ID"].ToString());
            DataTable dtGetPosts = new DataTable();
            daGetPosts.Fill(dtGetPosts);
            rpParent.DataSource = dtGetPosts;
            rpParent.DataBind();
        }

        protected void rpParent_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.DataItem != null)
            {
                int PostId = Convert.ToInt32(((System.Data.DataRowView)(e.Item.DataItem)).Row.ItemArray[0]);

                SqlDataAdapter daGetComments = new SqlDataAdapter("select cm.PostId, cm.User_id, cm.Comment,u.Name from CommentMaster cm inner join UserMaster u on (cm.User_Id=u.uId)  where cm.PostId=@PostId", _con);
                daGetComments.SelectCommand.Parameters.AddWithValue("@PostId", PostId);
                DataTable dtGetComment = new DataTable();
                daGetComments.Fill(dtGetComment);
                Repeater rp2 = (Repeater)e.Item.FindControl("rpChild");
                rp2.DataSource = dtGetComment;
                rp2.DataBind();
            }
        }

        protected void btnPost_Click(object sender, EventArgs e)
        {
            int flag = 0;
            if (txtPost.Text == string.Empty)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Messege", "alert('Please Enter Post Text')", true);
            }
            else
            {
                SqlCommand cmdInsert = new SqlCommand("insert into PostData (FromUser, PostContent, Date)values(@FromUser, @PostContent, @Date)", _con);
                cmdInsert.CommandType = CommandType.Text;
                cmdInsert.Parameters.AddWithValue("@FromUser", Session["ID"].ToString());
                //cmdInsert.Parameters.AddWithValue("@ToUser", ddlFriend.SelectedValue);
                cmdInsert.Parameters.AddWithValue("@PostContent", txtPost.Text);
                cmdInsert.Parameters.AddWithValue("@Date", DateTime.Now.Date);
                _con.Open();
                cmdInsert.ExecuteNonQuery();
                _con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Alert", "alert('Message post successfully')", true);
                txtPost.Text = string.Empty;
                rpParent.DataBind();
            }
        }


    }
}