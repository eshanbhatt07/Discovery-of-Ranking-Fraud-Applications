﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace DiscoverRankingFraud_App.Provider
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        public SqlConnection _conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int aId = Convert.ToInt32(Request.QueryString["aId"]);
                if (Request.QueryString["action"] == "edit")
                {
                    SqlCommand cmd = new SqlCommand("select aId, Name, Description, Photo, Path, isActivate from dbo.AppMaster where aId=@aId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] sqlPara = { new SqlParameter("@aId", SqlDbType.Int) { Value = aId } };
                    Helper objHelp = new Helper();
                    DataTable dt = objHelp.GetData(cmd, sqlPara, cmdType);
                    if (dt.Rows.Count > 0)
                    {
                        ddlActivate.SelectedIndex = Convert.ToInt32(dt.Rows[0]["isActivate"]);
                        txtName.Text = dt.Rows[0]["Name"].ToString();
                        txtDescription.Text = dt.Rows[0]["Description"].ToString();
                        imgLogo.ImageUrl = dt.Rows[0]["Photo"].ToString();
                        lblAPK.Text = dt.Rows[0]["Path"].ToString();
                    }
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            SqlDataAdapter _adp = new SqlDataAdapter("select * from Fraud_app_Master where fraud_app='" + txtName.Text + "'", _conn);
            DataTable dt = new DataTable();
            _adp.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Response.Write("<script>alert('applicatin is fraud please add proper app name.')</script>");
                    return;
            }


            int aId = Convert.ToInt32(Request.QueryString["aId"]);
            if (Request.QueryString["action"] == "edit")
            {
                if (fuLogo.HasFile)
                {
                    Guid gId = Guid.NewGuid();
                    string filename = Path.GetFileName(fuLogo.FileName);
                    int i = filename.IndexOf('.');
                    string ext = filename.Substring(i);
                    string Newname = gId.ToString() + ext;
                    fuLogo.SaveAs(Server.MapPath("~/AppLogos/") + Newname);
                    string FilePath = "/AppLogos/" + Newname;

                    SqlCommand cmdUpdate = new SqlCommand("update AppMaster set Name=@Name,Description=@Description,Photo=@Photo,Path=@Path,isActivate=@isActivate where aId=@aId");
                    CommandType cmdType = CommandType.Text;
                    SqlParameter[] sqlPara = {
                                             new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                             new SqlParameter("@Description",SqlDbType.VarChar){Value=txtDescription.Text},
                                             new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath},
                                             new SqlParameter("@Path",SqlDbType.VarChar){Value=lblAPK.Text},
                                             new SqlParameter("@isActivate",SqlDbType.Bit){Value=ddlActivate.SelectedValue},
                                             new SqlParameter("@aId",SqlDbType.Int){Value=aId}
                                             };
                    Helper objHelp = new Helper();
                    var res = objHelp.InsertData(cmdUpdate, sqlPara, cmdType);
                    if (res.ToString() == "1")
                    {
                        Response.Redirect("ManageApps.aspx?msg=update");
                    }
                }
            }
            else
            {
                if (fuLogo.HasFile)
                {
                    string APKPath = "";
                    if (fuAPK.HasFile)
                    {
                        string filenameApk = Path.GetFileName(fuAPK.FileName);
                        fuAPK.SaveAs(Server.MapPath("~/AppAPK/") + filenameApk);
                        APKPath = "/AppAPK/" + filenameApk;
                    }
                    Guid gId = Guid.NewGuid();
                    string filename = Path.GetFileName(fuLogo.FileName);
                    int i = filename.IndexOf('.');
                    string ext = filename.Substring(i);
                    string Newname = gId.ToString() + ext;
                    fuLogo.SaveAs(Server.MapPath("~/AppLogos/") + Newname);
                    string FilePath = "/AppLogos/" + Newname;


                    string malicious = txtbitly.Text;
                    if (txtbitly.Text.Length > 15)
                    {
                        string sub_malicious = malicious.Substring(0, 14);
                        string maliciousCode = "http://bit.ly/";
                        //  input.Substring(3, 3);
                        if (sub_malicious == maliciousCode)
                        {

                            SqlCommand cmdInsert = new SqlCommand("insert into AppMaster(Name,maliciousurl, Description, Photo, Path, isActivate,flag)values(@Name,@maliciousurl, @Description, @Photo, @Path, @isActivate,@flag)");
                            CommandType cmdType = CommandType.Text;
                            SqlParameter[] sqlPara = {
                                             new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                             new SqlParameter("@Description",SqlDbType.VarChar){Value=txtDescription.Text},
                                             new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath},
                                             new SqlParameter("@Path",SqlDbType.VarChar){Value=APKPath},
                                               new SqlParameter("@maliciousurl",SqlDbType.VarChar){Value=txtbitly.Text},
                                                 new SqlParameter("@flag",SqlDbType.VarChar){Value=1},
                                             new SqlParameter("@isActivate",SqlDbType.Bit){Value=Convert.ToInt32(ddlActivate.SelectedValue)}
                                             };
                            Helper objHelp = new Helper();
                            var res = objHelp.InsertData(cmdInsert, sqlPara, cmdType);
                            if (res.ToString() == "1")
                            {
                                Response.Redirect("ManageApps.aspx?msg=add");
                            }
                        }
                        else
                        {
                            SqlCommand cmdInsert = new SqlCommand("insert into AppMaster(Name,maliciousurl, Description, Photo, Path, isActivate,flag)values(@Name,@maliciousurl, @Description, @Photo, @Path, @isActivate,@flag)");
                            CommandType cmdType = CommandType.Text;
                            SqlParameter[] sqlPara = {
                                             new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                             new SqlParameter("@Description",SqlDbType.VarChar){Value=txtDescription.Text},
                                             new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath},
                                             new SqlParameter("@Path",SqlDbType.VarChar){Value=APKPath},
                                               new SqlParameter("@maliciousurl",SqlDbType.VarChar){Value=txtbitly.Text},
                                                 new SqlParameter("@flag",SqlDbType.VarChar){Value=0},
                                             new SqlParameter("@isActivate",SqlDbType.Bit){Value=Convert.ToInt32(ddlActivate.SelectedValue)}
                                             };
                            Helper objHelp = new Helper();
                            var res = objHelp.InsertData(cmdInsert, sqlPara, cmdType);
                            if (res.ToString() == "1")
                            {
                                Response.Redirect("ManageApps.aspx?msg=add");
                            }
                        }
                    }
                    else
                    {
                        SqlCommand cmdInsert = new SqlCommand("insert into AppMaster(Name,maliciousurl, Description, Photo, Path, isActivate,flag)values(@Name,@maliciousurl, @Description, @Photo, @Path, @isActivate,@flag)");
                        CommandType cmdType = CommandType.Text;
                        SqlParameter[] sqlPara = {
                                             new SqlParameter("@Name",SqlDbType.VarChar){Value=txtName.Text},
                                             new SqlParameter("@Description",SqlDbType.VarChar){Value=txtDescription.Text},
                                             new SqlParameter("@Photo",SqlDbType.VarChar){Value=FilePath},
                                             new SqlParameter("@Path",SqlDbType.VarChar){Value=APKPath},
                                               new SqlParameter("@maliciousurl",SqlDbType.VarChar){Value=txtbitly.Text},
                                                 new SqlParameter("@flag",SqlDbType.VarChar){Value=0},
                                             new SqlParameter("@isActivate",SqlDbType.Bit){Value=Convert.ToInt32(ddlActivate.SelectedValue)}
                                             };
                        Helper objHelp = new Helper();
                        var res = objHelp.InsertData(cmdInsert, sqlPara, cmdType);
                        if (res.ToString() == "1")
                        {
                            Response.Redirect("ManageApps.aspx?msg=add");
                        }
                    }
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageApps.aspx");
        }
    }
}